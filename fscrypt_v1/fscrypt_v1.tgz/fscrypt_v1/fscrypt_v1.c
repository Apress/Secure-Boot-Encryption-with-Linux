/*
 * Copyright (c) 2026 Rodolfo Giometti <giometti@enneenne.com>
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <sys/syscall.h>
#include <linux/fscrypt.h>
#include <linux/keyctl.h>

#define fatal(fmt, ...)							\
	do {								\
		fprintf(stderr, fmt "\n", ##__VA_ARGS__); 		\
		exit(EXIT_FAILURE);					\
	} while (0)

void usage(const char *name) {
	fprintf(stderr, "usage: %s <dir>\n", name);
	exit(EXIT_FAILURE);
}

int main(int argc, char *argv[])
{
	const char *dir;
	struct fscrypt_key logon_payload;
	char key_desc[64];
	char desc_hex[16 + 1];
	unsigned char desc_raw[8];
	long key_id;
	struct fscrypt_policy_v1 policy;
	int fd, tmpfd;
	int ret;

	if (argc != 2)
		usage(argv[0]);
	dir = argv[1];

	/* Open the target directory first */
	ret = open(dir, O_RDONLY | O_DIRECTORY);
	if (ret < 0)
		fatal("Error opening directory: %m");
	fd = ret;

	/* Check if the directory already has an encryption policy */
	memset(&policy, 0, sizeof(policy));
	ret = ioctl(fd, FS_IOC_GET_ENCRYPTION_POLICY, &policy);
	if (ret == 0) {
		/* Policy exists: extract the descriptor */
		if (policy.version != FSCRYPT_POLICY_V1)
			fatal("Directory encrypted with unsupported policy version");
		memcpy(desc_raw, policy.master_key_descriptor, 8);
	} else if (errno == ENODATA) {
		/* No policy: generate a new descriptor and set the policy */
		ret = open("/dev/urandom", O_RDONLY);
		if (ret < 0)
			fatal("cannot get data from /dev/urandom: %m");
		tmpfd = ret;
		ret = read(tmpfd, desc_raw, sizeof(desc_raw));
		if (ret != sizeof(desc_raw))
			fatal("cannot read random bytes for descriptor");
		close(tmpfd);

		policy.version = FSCRYPT_POLICY_V1;
		policy.contents_encryption_mode = FSCRYPT_MODE_AES_256_XTS;
		policy.filenames_encryption_mode = FSCRYPT_MODE_AES_256_CTS;
		policy.flags = FSCRYPT_POLICY_FLAGS_PAD_32;
		memcpy(policy.master_key_descriptor, desc_raw, 8);

		ret = ioctl(fd, FS_IOC_SET_ENCRYPTION_POLICY, &policy);
		if (ret)
			fatal("error on FS_IOC_SET_ENCRYPTION_POLICY: %m");
	} else {
		fatal("error on FS_IOC_GET_ENCRYPTION_POLICY: %m");
	}

	for (int i = 0; i < 8; i++)
		sprintf(&desc_hex[i * 2], "%02x", desc_raw[i]);

	/* Read the master key (64 bytes) from stdin */
	memset(&logon_payload, 0, sizeof(logon_payload));
	logon_payload.mode = 0;                  // Must be 0
	logon_payload.size = FSCRYPT_MAX_KEY_SIZE;
	ret = fread(logon_payload.raw, 1, FSCRYPT_MAX_KEY_SIZE, stdin);
	if (ret != FSCRYPT_MAX_KEY_SIZE)
		fatal("failed to read exactly 64 bytes from stdin");

	/* Format the required description string: "fscrypt:<16_hex_chars>" */
	snprintf(key_desc, sizeof(key_desc), "fscrypt:%s", desc_hex);

	/* Create the logon key. We use syscall directly to avoid external
	 * libkeyutils dependencies.
	 */
	key_id = syscall(SYS_add_key, "logon", key_desc,
				&logon_payload, sizeof(logon_payload),
				KEY_SPEC_SESSION_KEYRING);
	if (key_id < 0)
		fatal("cannot add logon key %s to keyring: %m", key_desc);

	printf("Policy v1 successfully applied to %s with " \
		"key '%s' (ID: %ld) successfully added to session keyring\n",
			dir, key_desc, key_id);

	close(fd);
	return 0;
}
