#define pr_fmt(fmt) "%s:%s: " fmt, KBUILD_MODNAME, __func__
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/key.h>
#include <linux/key-type.h>
#include <linux/err.h>

static const unsigned char key_payload[] = {
	0x24, 0xcc, 0xd6, 0x90, 0x79, 0x64, 0x3e, 0x83,
	0x35, 0xe2, 0xd8, 0xdb, 0xbf, 0x81, 0xcb, 0x54,
	0xad, 0x36, 0x5b, 0x79, 0x8c, 0x53, 0x99, 0x3b,
	0x3f, 0xc7, 0xfb, 0x73, 0xd8, 0x57, 0x42, 0x09
};
static const size_t key_len = sizeof(key_payload); 

static struct key *keyring, *key;
static const char *keyring_description = "keyring-injector",
		  *key_description = "rootfskey:fitimage"; 

static int __init key_injector_init(void)
{
	key_ref_t key_ref;
	int ret;

	pr_info("allocate keyring %s\n", keyring_description);
	keyring = keyring_alloc(keyring_description,
			GLOBAL_ROOT_UID, GLOBAL_ROOT_GID, current_cred(),
			(KEY_POS_ALL & ~KEY_POS_SETATTR) | \
						KEY_USR_ALL | KEY_USR_LINK,
			KEY_ALLOC_NOT_IN_QUOTA, NULL, NULL);
        if (IS_ERR(keyring)) {
                ret = PTR_ERR(keyring);
		pr_err("error allocating keyring\n");
		goto error_keyring_alloc;
	}
	pr_info("keyring %s allocated with serial #%d\n",
			keyring_description, keyring->serial);

	pr_info("insert logon key %s (%zu bytes)\n", key_description, key_len);
	key_ref = key_create_or_update(make_key_ref(keyring, true), 
			"logon", key_description,
			(const char *) key_payload, key_len,
			(KEY_POS_ALL & ~KEY_POS_SETATTR) | KEY_USR_ALL, 
			KEY_ALLOC_NOT_IN_QUOTA);
	if (IS_ERR(key_ref)) {
		pr_err("error inserting key\n");
		ret = PTR_ERR(key_ref);
		goto error_key_create;
	}

	ret = key_link(keyring, key_ref_to_ptr(key_ref));
	if (ret < 0) {
		pr_err("can't link key to keyring\n");
		goto error_key_link;
	}

	key = key_ref_to_ptr(key_ref);
	pr_info("logon key %s inserted with serial #%d\n",
			key_description, key->serial);

	return 0;

error_key_link:
	key_put(key);
error_key_create:
	key_put(keyring);
	
error_keyring_alloc:
	return ret;
}

static void __exit key_injector_exit(void)
{
	if (keyring && key) {
		key_invalidate(key);
		key_unlink(keyring, key);
		key_put(key);
		pr_info("key %s (#%d) removed\n",
				key_description, key->serial);
	}
	if (keyring) {
		key_put(keyring);
		pr_info("keyring %s (#%d) removed\n",
				keyring_description, keyring->serial);
	}

	pr_info("module unloaded\n");
}

module_init(key_injector_init);
module_exit(key_injector_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Rodolfo Giometti <giometti@enneenne.com>");
MODULE_DESCRIPTION("Inject a logon key into the kernel keyring");
