SUMMARY = "Kernel module to hardcode a Logon-type AES-256 key"
DESCRIPTION = "Kernel module for hardcoding a 32-byte AES-256 key into the kernel keyring as logon type"
MAINTAINER = "Rodolfo Giometti <giometti@enneenne.com>"
SECTION = "kernel"
LICENSE = "GPL-2.0-only"
LIC_FILES_CHKSUM = "file://${COMMON_LICENSE_DIR}/GPL-2.0-only;md5=801f80980d171dd6425610833a22dbe6"

# Source files
SRC_URI = " \
    file://key_injector.c \
    file://Makefile \
"

S = "${WORKDIR}" 

inherit module
